package com.example.si

object Routes {
    var mainScreen = "MainScreen"
    var registerScreen = "RegisterScreen"
    var loginScreen = "LoginScreen"
    var glossarioScreen = "Screen1"
    var gerenciarMedScreen = "Screen2"
    var addMedScreen = "Screen3"
    var listMedScreen = "Screen4"
    var editMedScreen = "Screen5"
    var prescriptionScreen = "Screen7"
    var calendarScreen = "Screen8"
    var profileScreen = "Screen9"
}