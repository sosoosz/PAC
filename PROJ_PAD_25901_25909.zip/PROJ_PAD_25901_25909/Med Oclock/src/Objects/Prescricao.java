package Objects;

import Functions.Database;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import java.util.Date;

public class Prescricao {

    private Integer id;

    private Integer utilizador_fk;

    private Integer medicamento_fk;

    private String dosagem;

    private Integer periodicidade;

    private String descricao;

    private Date data_inicio;

    private Date data_fim;

    //Obter valor dependendo do input.
    private Object getFieldValue(String fieldName) {
        return switch (fieldName) {
            case "id" -> this.id;
            case "utilizador_fk" -> this.utilizador_fk;
            case "medicamento_fk" -> this.medicamento_fk;
            case "dosagem" -> this.dosagem;
            case "periodicidade" -> this.periodicidade;
            case "descricao" -> this.descricao;
            case "data_inicio" -> this.data_inicio;
            case "data_fim" -> this.data_fim;

            default -> null;
        };
    }

    //Construtor que ao receber apenas o ID ira construir o objeto com as informações que estão na base de dados.
    //Exemplo:
    //Prescricao prescricaoTeste = New Prescricao(1)
    //Vai a base de dados buscar a informacao da prescricao com ID = 1 e colocar na prescricaoTeste
    public Prescricao(Integer id) throws SQLException, IOException, ClassNotFoundException {
        if (id != null && Database.getConnection() != null) {
            try {
                String sql = "SELECT * FROM prescricao WHERE id = ?";
                PreparedStatement statement = Database.getConnection().prepareStatement(sql);
                statement.setInt(1, id);

                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    this.id = resultSet.getInt("id");
                    this.utilizador_fk = resultSet.getInt("utilizador_fk");
                    this.medicamento_fk = resultSet.getInt("medicamento_fk");
                    this.dosagem = resultSet.getString("dosagem");
                    this.periodicidade = resultSet.getInt("periodicidade");
                    this.descricao = resultSet.getString("descricao");
                    this.data_inicio = resultSet.getDate("data_inicio");
                    this.data_fim = resultSet.getDate("data_fim");
                }

                resultSet.close();
                statement.close();
            } catch (SQLException | IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    //Construtor sem parametros
    public Prescricao() {
    }

    //Construtor com parametros
    public Prescricao(Integer id, Integer utilizador_fk, Integer medicamento_fk, String dosagem, Integer periodicidade, String descricao, Date data_inicio, Date data_fim) {
        this.id = id;
        this.utilizador_fk = utilizador_fk;
        this.medicamento_fk = medicamento_fk;
        this.dosagem = dosagem;
        this.periodicidade = periodicidade;
        this.descricao = descricao;
        this.data_inicio = data_inicio;
        this.data_fim = data_fim;
    }

    //Função que retorna a informação do objeto num array
    public Object[] toArray() {
        Object[] array = new Object[8];
        array[0] = this.id;
        array[1] = this.utilizador_fk;
        array[2] = this.medicamento_fk;
        array[3] = this.dosagem;
        array[4] = this.periodicidade;
        array[5] = this.descricao;
        array[6] = this.data_inicio;
        array[7] = this.data_fim;
        return array;
    }

    //Função que armazena as informações do OBJETO na base de dados, SE o ID for diferente de NULO irá dar UPDATE ao objeto com o mesmo id na base de dados.
    public void store() {
        String[] fields = {"id", "utilizador_fk", "medicamento_fk", "dosagem", "periodicidade", "descricao", "data_inicio", "data_fim"};

        if (this.id == null) {
            StringBuilder sql = new StringBuilder("INSERT INTO prescricao (" + String.join(",", fields) + ") VALUES (");
            sql.append(String.join(",", Collections.nCopies(fields.length, "?"))); // Add commas between placeholders
            sql.append(");");
            try {
                PreparedStatement statement = Database.getConnection().prepareStatement(String.valueOf(sql));

                int index = 1;
                for (String field : fields) {
                    Object value = getFieldValue(field);
                    if (value instanceof Integer) {
                        statement.setInt(index++, (Integer) value);
                    } else if (value instanceof String) {
                        statement.setString(index++, (String) value);
                    } else if (value instanceof Date) {
                        statement.setString(index++, String.valueOf(value));
                    } else if (value == null) {
                        statement.setNull(index++, java.sql.Types.NULL); // Handle null values
                    } else {
                        // Add handling for other data types if needed
                        throw new IllegalArgumentException("Unsupported field value type for " + field);
                    }
                }

                statement.executeUpdate();
                statement.close();

                this.id = Database.getNextIncrement("prescricao"); // Set ID after successful insert
            } catch (SQLException | IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else {
            StringBuilder values = new StringBuilder();
            for (String field : fields) {
                values.append(", ").append(field).append(" = ?");
            }

            String sql = "UPDATE prescricao SET " + values.substring(2) + " WHERE id = ?";

            try {
                PreparedStatement statement = Database.getConnection().prepareStatement(sql);

                int index = 1;
                for (String field : fields) {
                    Object value = getFieldValue(field);
                    if (value instanceof Integer) {
                        statement.setInt(index++, (Integer) value);
                    } else if (value instanceof String) {
                        statement.setString(index++, (String) value);
                    } else if (value == null) {
                        statement.setNull(index++, java.sql.Types.NULL); // Handle null values
                    } else {
                        // Add handling for other data types if needed
                        throw new IllegalArgumentException("Unsupported field value type for " + field);
                    }
                }

                statement.setInt(index++, this.id); // Add id as the last parameter

                statement.executeUpdate();
                statement.close();
            } catch (SQLException | IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    //Função que procura e devolve um ARRAY de objetos que tenham a informação que é inserida na função, se for tudo nulo irá retornar todos os objetos presentes na base de dados.
    public static Prescricao[] search(Integer id, Integer utilizador_fk, Integer medicamento_fk, String dosagem, Integer periodicidade, String descricao, String data_inicio, String data_fim) {
        String sql = "SELECT id FROM prescricao WHERE 1=1";

        // Build parameter list and set values Dynamically
        List<Object> params = new ArrayList<>();
        if (id != null) {
            sql += " AND (id = ?)";
            params.add(id);
        }
        if (utilizador_fk != null) {
            sql += " AND (utilizador_fk = ?)";
            params.add(utilizador_fk);
        }
        if (medicamento_fk != null) {
            sql += " AND (medicamento_fk = ?)";
            params.add(medicamento_fk);
        }
        if (dosagem != null) {
            sql += " AND (dosagem = ?)";
            params.add(dosagem);
        }
        if (periodicidade != null) {
            sql += " AND (periodicidade = ?)";
            params.add(periodicidade);
        }
        if (descricao != null) {
            sql += " AND (descricao = ?)";
            params.add(descricao);
        }
        if (data_inicio != null) {
            sql += " AND (data_inicio = ?)";
            params.add(data_inicio);
        }
        if (data_fim != null) {
            sql += " AND (data_fim = ?)";
            params.add(data_fim);
        }

        Prescricao[] ret = null;

        try {
            // Prepare the statement
            PreparedStatement statement = Objects.requireNonNull(Database.getConnection()).prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

            // Set parameters dynamically
            int index = 1;
            for (Object param : params) {
                if (param instanceof Integer) {
                    statement.setInt(index++, (Integer) param);
                } else if (param instanceof String) {
                    statement.setString(index++, (String) param);
                }

            }

            // Execute the query
            ResultSet resultSet = statement.executeQuery();

            resultSet.last();
            int rowCount = resultSet.getRow();
            resultSet.beforeFirst();

            if (rowCount > 0) {
                ret = new Prescricao[rowCount];
                int ind = 0;

                while (resultSet.next()) {
                    int prescricaoID = resultSet.getInt("id");
                    ret[ind] = new Prescricao(prescricaoID);
                    ind++;
                }
            }

            resultSet.close();
            statement.close();
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        return ret;
    }

    //Função que remove o proprio objeto da base de dados.
    public void remove() {
        if (this.id != null) {
            try {
                String sql = "DELETE FROM prescricao WHERE id = ?";
                PreparedStatement statement = Database.getConnection().prepareStatement(sql);
                statement.setInt(1, this.id);

                statement.executeUpdate();
                statement.close();
            } catch (SQLException | IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    //Funcao que PROCURA e DEVOLVE o NUMERO de objetos presentes na base de dados, repito, NAO DEVOLVE O OBJETO, DEVOLVE A SUA QUANTIDADE.
    public static int find(Integer id, Integer utilizador_fk, Integer medicamento_fk, String dosagem, Integer periodicidade, String descricao, String data_inicio, String data_fim) {
        String sql = "SELECT id FROM prescricao WHERE 1=1";

        // Build parameter list dynamically
        List<Object> params = new ArrayList<>();
        if (id != null) {
            sql += " AND (id = ?)";
            params.add(id);
        }
        if (utilizador_fk != null) {
            sql += " AND (utilizador_fk = ?)";
            params.add(utilizador_fk);
        }
        if (medicamento_fk != null) {
            sql += " AND (medicamento_fk = ?)";
            params.add(medicamento_fk);
        }
        if (dosagem != null) {
            sql += " AND (dosagem = ?)";
            params.add(dosagem);
        }
        if (periodicidade != null) {
            sql += " AND (periodicidade = ?)";
            params.add(periodicidade);
        }
        if (descricao != null) {
            sql += " AND (descricao = ?)";
            params.add(descricao);
        }
        if (data_inicio != null) {
            sql += " AND (data_inicio = ?)";
            params.add(data_inicio);
        }
        if (data_fim != null) {
            sql += " AND (data_fim = ?)";
            params.add(data_fim);
        }

        try {
            PreparedStatement statement = Database.getConnection().prepareStatement(sql);

            // Set parameters dynamically
            int index = 1;
            for (Object param : params) {
                if (param instanceof Integer) {
                    statement.setInt(index++, (Integer) param);
                } else if (param instanceof String) {
                    statement.setString(index++, (String) param);
                }else if (param instanceof Date) {
                        statement.setString(index++, String.valueOf(param));

                } else {
                    // Add handling for other data types if needed
                    throw new IllegalArgumentException("Unsupported parameter type: " + param.getClass());
                }
            }

            ResultSet resultSet = statement.executeQuery();
            int count = resultSet.next() ? 1 : 0;
            resultSet.close();
            statement.close();
            return count;
        } catch (SQLException | IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return 0;
        }
    }

    //Funçao estatica que ira remover um objeto da base de dados que tenha o ID que foi inserido nos parametros
    public static void remover(Integer id) {
        if (id != null) {
            try {
                String sql = "DELETE FROM prescricao WHERE id = ?";
                PreparedStatement statement = Database.getConnection().prepareStatement(sql);
                statement.setInt(1, id);

                statement.executeUpdate();
                statement.close();
            } catch (SQLException | IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("ID NULL");
        }
    }

    //Funcao que obtem o nome do medicamento apartir do seu ID
    public String getMedicamentoNome() {
        if(getMedicamento_fk() != null){
            Medicamento[] medicamento = Medicamento.search(getMedicamento_fk(),null,null,null,null);
            return medicamento[0].getNome();
        }
        System.out.println("ERRO - medicamento não encontrado");
        return null;
    }

    //GETTERS E SETTERS ABAIXO


    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUtilizador_fk() {
        return utilizador_fk;
    }

    public void setUtilizador_fk(Integer utilizador_fk) {
        this.utilizador_fk = utilizador_fk;
    }

    public Integer getMedicamento_fk() {
        return medicamento_fk;
    }

    public void setMedicamento_fk(Integer medicamento_fk) {
        this.medicamento_fk = medicamento_fk;
    }

    public String getDosagem() {
        return dosagem;
    }

    public void setDosagem(String dosagem) {
        this.dosagem = dosagem;
    }

    public Integer getPeriodicidade() {
        return periodicidade;
    }

    public void setPeriodicidade(Integer periodicidade) {
        this.periodicidade = periodicidade;
    }

    public Date getData_inicio() {
        return data_inicio;
    }

    public void setData_inicio(Date data_inicio) {
        this.data_inicio = data_inicio;
    }

    public Date getData_fim() {
        return data_fim;
    }

    public void setData_fim(Date data_fim) {
        this.data_fim = data_fim;
    }
}
