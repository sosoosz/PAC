package Objects;

import Functions.Database;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;


//NOTA Os comentarios estão presentes apenas no objeto Prescricao, pois as funções sao similares.
//No entanto funções que são especificas ao objeto estarão comentadas


public class Utilizador {

    private Integer id;

    private String nome_utilizador;

    private String nome_completo;

    private String password;

    private Object getFieldValue(String fieldName) {
        return switch (fieldName) {
            case "id" -> this.id;
            case "nome_utilizador" -> this.nome_utilizador;
            case "nome_completo" -> this.nome_completo;
            case "password" -> this.password;
            default -> null;
        };
    }

    public Utilizador(){

    }

    public Utilizador(int id, String nome_utilizador, String nome_completo, String password) {
        this.id = id;
        this.nome_utilizador = nome_utilizador;
        this.nome_completo = nome_completo;
        this.password = password;
    }

    public Utilizador(Integer id) throws SQLException, IOException, ClassNotFoundException {
        if (id != null && Database.getConnection() != null) {
            try {
                String sql = "SELECT * FROM utilizador WHERE id = ?";
                PreparedStatement statement = Database.getConnection().prepareStatement(sql);
                statement.setInt(1, id);

                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    this.id = resultSet.getInt("id");
                    this.nome_utilizador = resultSet.getString("nome_utilizador");
                    this.nome_completo = resultSet.getString("nome_completo");
                    this.password = resultSet.getString("password");
                }

                resultSet.close();
                statement.close();
            } catch (SQLException | IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public Utilizador(Utilizador utilizador) {
        this.id = utilizador.getId();
        this.nome_utilizador = utilizador.getNome_utilizador();
        this.nome_completo = utilizador.getNome_completo();
        this.password = utilizador.getPassword();
    }

    public Object[] toArray() {
        Object[] array = new Object[3];
        array[0] = this.id;
        array[1] = this.nome_utilizador;
        array[2] = this.nome_completo;
        return array;
    }

    public void store() {
        String[] fields = {"id", "nome_utilizador", "nome_completo", "password"};

        if (this.id == null) {
            this.id = Database.getNextIncrement("utilizador");

            StringBuilder sql = new StringBuilder("INSERT INTO utilizador (" + String.join(",", fields) + ") VALUES (");
            sql.append(String.join(",", Collections.nCopies(fields.length, "?"))); // Add commas between placeholders
            sql.append(");");
            try {
                PreparedStatement statement = Database.getConnection().prepareStatement(sql.toString());

                int index = 1;
                for (String field : fields) {
                    Object value = this.getFieldValue(field);
                    if (value instanceof Integer) {
                        statement.setInt(index++, (Integer) value);
                    } else if (value instanceof String) {
                        statement.setString(index++, (String) value);
                    } else if (value == null) {
                        statement.setNull(index++, java.sql.Types.NULL);
                    } else {
                        // Add handling for other data types if needed
                        throw new IllegalArgumentException("Unsupported field value type for " + field);
                    }
                }

                statement.executeUpdate();
                statement.close();
            } catch (SQLException | IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else {
            StringBuilder values = new StringBuilder();
            for (String field : fields) {
                values.append(", ").append(field).append(" = ?");
            }

            String sql = "UPDATE utilizador SET " + values.substring(2) + " WHERE id = ?";

            try {
                PreparedStatement statement = Database.getConnection().prepareStatement(sql);

                int index = 1;
                for (String field : fields) {
                    Object value = this.getFieldValue(field);
                    if (value instanceof Integer) {
                        statement.setInt(index++, (Integer) value);
                    } else if (value instanceof String) {
                        statement.setString(index++, (String) value);
                    } else if (value == null) {
                        statement.setNull(index++, java.sql.Types.NULL);
                    } else {
                        // Add handling for other data types if needed
                        throw new IllegalArgumentException("Unsupported field value type for " + field);
                    }
                }

                statement.setInt(index, this.id); // Add id as the last parameter

                statement.executeUpdate();
                statement.close();
            } catch (SQLException | IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }


    public static Utilizador[] search(Integer id, String nome_utilizador, String nome_completo, String password) {
        StringBuilder sql = new StringBuilder("SELECT id FROM utilizador WHERE 1=1");

        List<Object> params = new ArrayList<>();
        if (id != null) {
            sql.append(" AND (id = ?)");
            params.add(id);
        }
        if (nome_utilizador != null) {
            sql.append(" AND (nome_utilizador = ?)");
            params.add(nome_utilizador);
        }
        if (nome_completo != null) {
            sql.append(" AND (nome_completo = ?)");
            params.add(nome_completo);
        }
        if (password != null) {
            sql.append(" AND (password = ?)");
            params.add(password);
        }

        Utilizador[] ret = null;

        try {
            PreparedStatement statement = Database.getConnection().prepareStatement(sql.toString(),ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

            int index = 1;
            for (Object param : params) {
                if (param instanceof Integer) {
                    statement.setInt(index++, (Integer) param);
                } else if (param instanceof String) {
                    statement.setString(index++, (String) param);
                } else {
                    // Add handling for other data types if needed
                    throw new IllegalArgumentException("Unsupported parameter type: " + param.getClass());
                }
            }

            ResultSet resultSet = statement.executeQuery();

            resultSet.last();
            int rowCount = resultSet.getRow();
            resultSet.beforeFirst();

            if (rowCount > 0) {
                ret = new Utilizador[rowCount];
                int index2 = 0;

                while (resultSet.next()) {
                    int utilizadorID = resultSet.getInt("id");
                    ret[index2] = new Utilizador(utilizadorID);
                    index2++;
                }
            }

            resultSet.close();
            statement.close();
        } catch (SQLException | IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return ret;
    }

    public void remove() {
        if (this.id != null) {
            try {
                // Delete related entries in reverse order (child to parent)

                String sql3 = "DELETE FROM prescricao WHERE utilizador_fk = ?";
                PreparedStatement statement3 = Database.getConnection().prepareStatement(sql3);
                statement3.setInt(1, this.id);
                statement3.executeUpdate();
                statement3.close();

                String sql2 = "DELETE FROM medicamento WHERE utilizador_fk = ?";
                PreparedStatement statement2 = Database.getConnection().prepareStatement(sql2);
                statement2.setInt(1, this.id);
                statement2.executeUpdate();
                statement2.close();


                String sql = "DELETE FROM utilizador WHERE id = ?";
                PreparedStatement statement = Database.getConnection().prepareStatement(sql);
                statement.setInt(1, this.id);
                statement.executeUpdate();
                statement.close();
            } catch (SQLException | IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public static int find(Integer id, String nome_utilizador, String nome_completo, String password) {
        StringBuilder sql = new StringBuilder("SELECT COUNT(*) FROM utilizador WHERE 1=1");

        List<Object> params = new ArrayList<>();
        if (id != null) {
            sql.append(" AND (id = ?)");
            params.add(id);
        }
        if (nome_utilizador != null) {
            sql.append(" AND (nome_utilizador = ?)");
            params.add(nome_utilizador);
        }
        if (nome_completo != null) {
            sql.append(" AND (nome_completo = ?)");
            params.add(nome_completo);
        }
        if (password != null) {
            sql.append(" AND (password = ?)");
            params.add(password);
        }

        try {
            PreparedStatement statement = Database.getConnection().prepareStatement(sql.toString());

            int index = 1;
            for (Object param : params) {
                if (param instanceof Integer) {
                    statement.setInt(index++, (Integer) param);
                } else if (param instanceof String) {
                    statement.setString(index++, (String) param);
                } else {
                    // Add handling for other data types if needed
                    throw new IllegalArgumentException("Unsupported parameter type: " + param.getClass());
                }
            }

            ResultSet resultSet = statement.executeQuery();
            int count = resultSet.next() ? resultSet.getInt(1) : 0;
            resultSet.close();
            statement.close();
            return count;
        } catch (SQLException | IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return 0;
        }
    }


    public static void remover(Integer id) {
        if (id != null) {
            try {
                // Delete related entries in reverse order (child to parent)
                String sql3 = "DELETE FROM prescricao WHERE utilizador_fk = ?";
                PreparedStatement statement3 = Database.getConnection().prepareStatement(sql3);
                statement3.setInt(1, id);
                statement3.executeUpdate();
                statement3.close();

                String sql2 = "DELETE FROM medicamento WHERE utilizador_fk = ?";
                PreparedStatement statement2 = Database.getConnection().prepareStatement(sql2);
                statement2.setInt(1, id);
                statement2.executeUpdate();
                statement2.close();

                String sql = "DELETE FROM utilizador WHERE id = ?";
                PreparedStatement statement = Database.getConnection().prepareStatement(sql);
                statement.setInt(1, id);
                statement.executeUpdate();
                statement.close();
            } catch (SQLException | IOException | ClassNotFoundException e) {
                // Handle specific foreign key constraint violation exception (if applicable)
                if (e instanceof SQLException && e.getMessage().contains("foreign key constraint violation")) {
                    System.err.println("Deletion failed: Foreign key constraint violation. Related entries exist.");
                } else {
                    e.printStackTrace();
                }
            }
        } else {
            System.out.println("ID NULL");
        }
    }

    //GETTERS E SETTERS ABAIXO

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome_utilizador() {
        return nome_utilizador;
    }

    public void setNome_utilizador(String nome_utilizador) {
        this.nome_utilizador = nome_utilizador;
    }

    public String getNome_completo() {
        return nome_completo;
    }

    public void setNome_completo(String nome_completo) {
        this.nome_completo = nome_completo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
