package Objects;

import Functions.Database;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

//NOTA Os comentarios estão presentes apenas no objeto Prescricao, pois as funções sao similares.
//No entanto funções que são especificas ao objeto estarão comentadas
public class Medicamento {

    private Integer id;

    private Integer utilizador_fk;
    private String nome;

    private String descricao;

    private String tipo;

    private Object getFieldValue(String fieldName) {
        return switch (fieldName) {
            case "id" -> this.id;
            case "utilizador_fk" -> this.utilizador_fk;
            case "nome" -> this.nome;
            case "descricao" -> this.descricao;
            case "tipo" -> this.tipo;
            default -> null;
        };
    }

    public Medicamento() {
    }

    public Medicamento(Integer id,Integer utilizador_fk, String nome, String descricao, String tipo) {
        this.id = id;
        this.utilizador_fk = utilizador_fk;
        this.nome = nome;
        this.descricao = descricao;
        this.tipo = tipo;
    }

    public Medicamento(Integer id) throws SQLException, IOException, ClassNotFoundException {
        if (id != null && Database.getConnection() != null) {
            try {
                String sql = "SELECT * FROM medicamento WHERE id = ?";
                PreparedStatement statement = Database.getConnection().prepareStatement(sql);
                statement.setInt(1, id);

                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    this.id = resultSet.getInt("id");
                    this.utilizador_fk = resultSet.getInt("utilizador_fk");
                    this.nome = resultSet.getString("nome");
                    this.descricao = resultSet.getString("descricao");
                    this.tipo = resultSet.getString("tipo");
                }

                resultSet.close();
                statement.close();
            } catch (SQLException | IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public Medicamento(Medicamento medicamento) {
        this.id = medicamento.getId();
        this.utilizador_fk = medicamento.getUtilizador_fk();
        this.nome = medicamento.nome;
        this.descricao = medicamento.descricao;
        this.tipo = medicamento.tipo;
    }

    public Object[] toArray() {
        Object[] array = new Object[5];
        array[0] = this.id;
        array[1] = this.utilizador_fk;
        array[2] = this.nome;
        array[3] = this.descricao;
        array[4] = this.tipo;
        return array;
    }

    public void store() {
        String[] fields = {"id", "utilizador_fk", "nome", "descricao", "tipo"};

        if (this.id == null) {
            this.id = Database.getNextIncrement("medicamento");

            StringBuilder sql = new StringBuilder("INSERT INTO medicamento (" + String.join(",", fields) + ") VALUES (");
            sql.append(String.join(",", Collections.nCopies(fields.length, "?"))); // Add commas between placeholders
            sql.append(");");

            try {
                PreparedStatement statement = Database.getConnection().prepareStatement(String.valueOf(sql));

                int index = 1;
                for (String field : fields) {
                    Object value = getFieldValue(field);
                    if (value instanceof Integer) {
                        statement.setInt(index++, (Integer) value);
                    } else if (value instanceof String) {
                        statement.setString(index++, (String) value);
                    } else if (value == null) {
                        statement.setNull(index++, java.sql.Types.NULL); // Use java.sql.Types.NULL
                    } else {
                        // Add handling for other data types if needed
                        throw new IllegalArgumentException("Unsupported field value type for " + field);
                    }
                }

                statement.executeUpdate();
                statement.close();
            } catch (SQLException | IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else {
            StringBuilder values = new StringBuilder();
            for (String field : fields) {
                values.append(", ").append(field).append(" = ?");
            }

            String sql = "UPDATE medicamento SET " + values.substring(2) + " WHERE id = ?";

            try {
                PreparedStatement statement = Database.getConnection().prepareStatement(sql);

                int index = 1;
                for (String field : fields) {
                    Object value = getFieldValue(field);
                    if (value instanceof Integer) {
                        statement.setInt(index++, (Integer) value);
                    } else if (value instanceof String) {
                        statement.setString(index++, (String) value);
                    } else if (value == null) {
                        statement.setNull(index++, java.sql.Types.NULL); // Use java.sql.Types.NULL
                    } else {
                        // Add handling for other data types if needed
                        throw new IllegalArgumentException("Unsupported field value type for " + field);
                    }
                }

                statement.setInt(index++, this.id); // Add id as the last parameter

                statement.executeUpdate();
                statement.close();
            } catch (SQLException | IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }



    public static Medicamento[] search(Integer id, Integer utilizador_fk, String nome, String descricao, String tipo) {
        StringBuilder sql = new StringBuilder("SELECT id FROM medicamento WHERE 1=1");

        List<Object> params = new ArrayList<>();
        if (id != null) {
            sql.append(" AND (id = ?)");
            params.add(id);
        }
        if (utilizador_fk != null) {
            sql.append(" AND (utilizador_fk = ?)");
            params.add(utilizador_fk);
        }
        if (nome != null) {
            sql.append(" AND (nome = ?)");
            params.add(nome);
        }
        if (descricao != null) {
            sql.append(" AND (descricao = ?)");
            params.add(descricao);
        }
        if (tipo != null) {
            sql.append(" AND (tipo = ?)");
            params.add(tipo);
        }

        Medicamento[] ret = null;

        try {
            PreparedStatement statement = Database.getConnection().prepareStatement(sql.toString(),ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

            int index = 1;
            for (Object param : params) {
                if (param instanceof Integer) {
                    statement.setInt(index++, (Integer) param);
                } else if (param instanceof String) {
                    statement.setString(index++, (String) param);
                } else {
                    // Add handling for other data types if needed
                    throw new IllegalArgumentException("Unsupported parameter type: " + param.getClass());
                }
            }

            ResultSet resultSet = statement.executeQuery();

            resultSet.last();
            int rowCount = resultSet.getRow();
            resultSet.beforeFirst();

            if (rowCount > 0) {
                ret = new Medicamento[rowCount];
                int index1 = 0;

                while (resultSet.next()) {
                    int medicamentoID = resultSet.getInt("id");
                    ret[index1] = new Medicamento(medicamentoID);
                    index1++;
                }
            }

            resultSet.close();
            statement.close();
        } catch (SQLException | IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return ret;
    }

    public void remove() {
        if (this.id != null) {
            try {
                String sql3 = "DELETE FROM medicamento_has_prescricao WHERE medicamento_fk = ?";
                PreparedStatement statement3 = Database.getConnection().prepareStatement(sql3);
                statement3.setInt(1, this.id);
                statement3.executeUpdate();
                statement3.close(); // Close each prepared statement separately



                String sql = "DELETE FROM medicamento WHERE id = ?";
                PreparedStatement statement = Database.getConnection().prepareStatement(sql);
                statement.setInt(1, this.id);
                statement.executeUpdate();
                statement.close();
            } catch (SQLException | IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }


    public static int find(Integer id, Integer utilizador_fk, String nome, String descricao, String tipo) {
        StringBuilder sql = new StringBuilder("SELECT COUNT(*) FROM medicamento WHERE 1=1");

        List<Object> params = new ArrayList<>();
        if (id != null) {
            sql.append(" AND (id = ?)");
            params.add(id);
        }
        if (utilizador_fk != null) {
            sql.append(" AND (utilizador_fk = ?)");
            params.add(utilizador_fk);
        }
        if (nome != null) {
            sql.append(" AND (nome = ?)");
            params.add(nome);
        }
        if (descricao != null) {
            sql.append(" AND (descricao = ?)");
            params.add(descricao);
        }
        if (tipo != null) {
            sql.append(" AND (tipo = ?)");
            params.add(tipo);
        }

        try {
            PreparedStatement statement = Database.getConnection().prepareStatement(sql.toString());

            int index = 1;
            for (Object param : params) {
                if (param instanceof Integer) {
                    statement.setInt(index++, (Integer) param);
                } else if (param instanceof String) {
                    statement.setString(index++, (String) param);
                } else {
                    // Add handling for other data types if needed
                    throw new IllegalArgumentException("Unsupported parameter type: " + param.getClass());
                }
            }

            ResultSet resultSet = statement.executeQuery();
            int count = resultSet.next() ? resultSet.getInt(1) : 0;
            resultSet.close();
            statement.close();
            return count;
        } catch (SQLException | IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return 0;
        }
    }


    public static void remover(Integer id) {
        if (id != null) {
            try {
                String sql3 = "DELETE FROM prescricao WHERE medicamento_fk = ?";
                PreparedStatement statement3 = Database.getConnection().prepareStatement(sql3);
                statement3.setInt(1, id);
                statement3.executeUpdate();
                statement3.close(); // Close each prepared statement separately



                String sql = "DELETE FROM medicamento WHERE id = ?";
                PreparedStatement statement = Database.getConnection().prepareStatement(sql);
                statement.setInt(1, id);
                statement.executeUpdate();
                statement.close();
            } catch (SQLException | IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("ID NULL");
        }
    }

    //Funcao que escreve todos os medicamentos
    public static void printAllMedicamentoInfo(Medicamento[] medicamentos) {
        if (medicamentos != null){
            int i = 1;
            for(Medicamento medicamento : medicamentos){
                System.out.println("--------------------------");
                System.out.println("Nº Medicamento: " + i);
                System.out.println("Nome: " + medicamento.getNome());
                System.out.println("Descrição: " + medicamento.getDescricao());
                System.out.println("Tipo: " + medicamento.getTipo());
                System.out.println("--------------------------");
                i ++;
            }
        }else {
            System.out.println("Nada a apresentar");
        }


    }
    //Funcao que escreve apenas 1 medicamento, passado o seu ID
    public static void printMedicamentoInfo(Integer medicamentoID) throws SQLException, IOException, ClassNotFoundException {
        if (medicamentoID != null){
            Medicamento medicamento = new Medicamento(medicamentoID);
            System.out.println("--------------------------");
            System.out.println("Nome: " + medicamento.getNome());
            System.out.println("Descrição: " + medicamento.getDescricao());
            System.out.println("Tipo: " + medicamento.getTipo());
            System.out.println("--------------------------");
        }else {
            System.out.println("ERRO - ID DO MEDICAMENTO NULO");
        }


    }

    //GETTERS E SETTERS ABAIXO


    public Integer getUtilizador_fk() {
        return utilizador_fk;
    }

    public void setUtilizador_fk(Integer utilizador_fk) {
        this.utilizador_fk = utilizador_fk;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
