package Menus;

import Functions.LoginController;
import Functions.Utils;
import Objects.Utilizador;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.Scanner;

public class Menu_Utilizador {

    private Utilizador utilizador;
    private final Integer userID;

    // Construtor que recebe o ID do utilizador
    public Menu_Utilizador(Integer userID) throws SQLException, IOException, NoSuchAlgorithmException, ClassNotFoundException {
        this.userID = userID;
        Utilizador[] utilizador = Utilizador.search(userID, null, null, null);
        this.utilizador = utilizador[0];
        mostrarMenu();
    }

    // Método para exibir o menu do utilizador
    private void mostrarMenu() throws SQLException, IOException, NoSuchAlgorithmException, ClassNotFoundException {
        Scanner scanner = new Scanner(System.in);
        exibirDadosPerfil();
        exibirOpcoes();

        int opcao = scanner.nextInt();
        scanner.nextLine(); // Limpar o buffer do scanner

        processarOpcao(opcao);
    }

    // Método para exibir os dados do perfil do utilizador
    private void exibirDadosPerfil() {
        System.out.println("--------------------------");
        System.out.println("Bem-vindo ao seu perfil. Aqui estão os seus dados:");
        System.out.println("Nome: " + utilizador.getNome_completo());
        System.out.println("Nome de Utilizador: " + utilizador.getNome_utilizador());
        System.out.println("--------------------------");
    }

    // Método para exibir as opções disponíveis no menu do utilizador
    private void exibirOpcoes() {
        System.out.println("\n Escolha uma opção:");
        System.out.println("--------------");
        System.out.println("1. Editar nome.");
        System.out.println("2. Editar nome de utilizador.");
        System.out.println("3. Editar palavra-passe.");
        System.out.println("4. Apagar dados do perfil.");
        System.out.println("0. Voltar.");
    }

    // Método para processar a opção escolhida pelo utilizador
    private void processarOpcao(int opcao) throws SQLException, IOException, NoSuchAlgorithmException, ClassNotFoundException {
        switch (opcao) {
            case 1 -> editarNome();
            case 2 -> editarNomeUtilizador();
            case 3 -> editarPalavraPasse();
            case 4 -> deletarPerfil();
            case 0 -> {
                System.out.println("Voltando ao menu principal.");
                Menu_Principal menu_principal = new Menu_Principal(userID);
                menu_principal.mostrarMenu();
            }
            default -> {
                System.out.println("Por favor, insira uma opção válida.");
                mostrarMenu();
            }
        }
    }

    // Método para editar o nome do utilizador
    private void editarNome() throws SQLException, IOException, NoSuchAlgorithmException, ClassNotFoundException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Escreva o novo nome:");
        String nome = scanner.nextLine();
        utilizador.setNome_completo(nome);
        utilizador.store();
        System.out.println("Alterações guardadas...");
        mostrarMenu();
    }

    // Método para editar o nome de utilizador
    private void editarNomeUtilizador() throws SQLException, IOException, NoSuchAlgorithmException, ClassNotFoundException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Escreva o novo nome de utilizador:");
        String nomeUtilizador = scanner.nextLine();
        utilizador.setNome_utilizador(nomeUtilizador);
        utilizador.store();
        System.out.println("Alterações guardadas...");
        mostrarMenu();
    }

    // Método para editar a palavra-passe
    private void editarPalavraPasse() throws NoSuchAlgorithmException, SQLException, IOException, ClassNotFoundException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Insira a sua palavra-passe atual:");
        String password = scanner.nextLine();

        // Verifica se a palavra-passe atual está correta
        if (Utils.toHexString(Utils.getSHA(password)).equals(utilizador.getPassword())) {
            int success = 0;
            do {
                System.out.println("Insira a nova palavra-passe:");
                String novaPassword = scanner.nextLine();
                System.out.println("Reinsira a nova palavra-passe:");
                String rePassword = scanner.nextLine();

                // Verifica se as novas palavras-passe coincidem
                if (novaPassword.equals(rePassword)) {
                    utilizador.setPassword(Utils.toHexString(Utils.getSHA(novaPassword))); // Encriptação SHA256
                    utilizador.store();
                    success = 1;
                    System.err.println("PALAVRA-PASSE ALTERADA");
                    mostrarMenu();
                } else {
                    System.out.println("As palavras-passe não coincidem");
                    editarPalavraPasse();
                }
            } while (success == 1);
        } else {
            System.out.println("Palavra-passe incorreta");
            mostrarMenu();
        }
    }

    // Método para deletar o perfil do utilizador
    private void deletarPerfil() throws SQLException, IOException, NoSuchAlgorithmException, ClassNotFoundException {
        Scanner scanner = new Scanner(System.in);
        System.err.println("AVISO: AO APAGAR O PERFIL, TAMBÉM SERÃO APAGADAS AS PRESCRIÇÕES E OS MEDICAMENTOS ASSOCIADOS AO PERFIL");
        System.out.println("Tem a certeza de que deseja apagar a sua conta? (S/N)");
        String resposta = scanner.nextLine();

        if (resposta.equalsIgnoreCase("S")) {
            utilizador.remove();
            System.err.println("CONTA APAGADA");
            voltarLogin();
        } else if (resposta.equalsIgnoreCase("N")) {
            mostrarMenu();
        }
    }

    // Método para retornar ao login
    private static void voltarLogin() throws NoSuchAlgorithmException, SQLException, IOException, ClassNotFoundException {
        LoginController loginController = new LoginController();
        boolean loggedIn = loginController.iniciar();
        if (loggedIn) {
            Integer userID = loginController.getUserID();
            if (userID != null) {
                Menu_Principal menu_principal = new Menu_Principal(userID);
                menu_principal.mostrarMenu();
            } else {
                System.out.println("Falha ao obter informações do utilizador. A sair da aplicação.");
            }
        }
    }
}
