package Menus;

import Objects.Prescricao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;


public class Menu_Calendario {

    private Map<LocalDate, List<Prescricao>> calendario;

    // Construtor que inicializa o calendário
    public Menu_Calendario() {
        this.calendario = new HashMap<>();
    }

    // Método para converter uma data (Date) para uma string formatada
    public String fromDatetoString(Date date){
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MMM-dd");
        return dateFormat.format(date);
    }

    // Método para converter uma string para LocalDate
    public LocalDate fromStringToLocalDate(String date){
        Locale localePT = new Locale("pt", "PT");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MMM-dd");
        formatter = formatter.withLocale(localePT);
        return LocalDate.parse(date, formatter);
    }

    // Método para gerar o calendário com base nas prescrições
    public void gerarCalendario(List<Prescricao> prescricoes) {
        LocalDate hoje = LocalDate.now();

        for (int i = 0; i < 7; i++) {
            LocalDate dataAtual = hoje.plusDays(i);

            for (Prescricao prescricao : prescricoes) {
                LocalDate dataInicio = fromStringToLocalDate(fromDatetoString(prescricao.getData_inicio()));
                LocalDate dataFim = fromStringToLocalDate(fromDatetoString(prescricao.getData_fim()));

                if (dataAtual.isEqual(dataInicio) || (dataAtual.isAfter(dataInicio) &&
                        (dataAtual.isBefore(dataFim) || dataAtual.isEqual(dataFim)))) {
                    if (i % prescricao.getPeriodicidade() == 0) {
                        // Adiciona a prescrição ao calendário
                        calendario.merge(dataAtual, new ArrayList<>(List.of(prescricao)), (existing, additional) -> {
                            existing.addAll(additional);
                            return existing;
                        });
                    }
                }
            }
        }
    }

    // Método para exibir o calendário
    public void exibirCalendario() {
        for (Map.Entry<LocalDate, List<Prescricao>> entry : calendario.entrySet()) {
            System.out.println("Data: " + entry.getKey().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
            System.out.println("Prescrições:");

            for (Prescricao prescricao : entry.getValue()) {
                System.out.println("- Medicamento: " + prescricao.getMedicamentoNome());
                System.out.println("  Dosagem: " + prescricao.getDosagem());
                System.out.println("  Descrição: " + prescricao.getDescricao());
            }
            System.out.println("--------------");
        }
    }
}
