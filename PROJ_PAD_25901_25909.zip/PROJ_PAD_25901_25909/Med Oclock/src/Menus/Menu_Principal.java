package Menus;

import Functions.Utils;
import Objects.Utilizador;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.Scanner;

public class Menu_Principal {

    private Integer userID;
    private String nome;

    // Construtor que recebe o ID do utilizador
    public Menu_Principal(Integer idUtilizador) {
        this.userID = idUtilizador;
        Utilizador[] utilizador = Utilizador.search(idUtilizador, null, null, null);
        this.nome = utilizador[0].getNome_completo();
    }

    // Método para exibir o menu principal
    public void mostrarMenu() throws SQLException, IOException, NoSuchAlgorithmException, ClassNotFoundException {
        System.out.println("--------------");
        System.out.println("Bem-vindo ao Med O'clock, " + nome + ", escolha o que deseja fazer:");
        System.out.println("1. Acessar o calendário de medicamentos");
        System.out.println("2. Acessar o glossário");
        System.out.println("3. Acessar o seu perfil");
        System.out.println("0. Sair da aplicação");
        System.out.println("--------------");
        int escolha = lerOpcao();

        switch (escolha) {
            case 1 -> acessarCalendarioMedicacao();
            case 2 -> acessarGlossario();
            case 3 -> acessarPerfil();
            case 0 -> sair();
            default -> {
                System.out.println("Opção inválida, por favor, tente novamente.");
                mostrarMenu();
            }
        }
    }

    // Método para ler a opção digitada pelo utilizador
    private int lerOpcao() {
        Scanner scanner = new Scanner(System.in);
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Entrada inválida, por favor, insira um número.");
            return lerOpcao();
        }
    }

    // Método para acessar o calendário de medicamentos
    private void acessarCalendarioMedicacao() throws SQLException, IOException, NoSuchAlgorithmException, ClassNotFoundException {
        Menu_Calendario menuCalendario = new Menu_Calendario();

        if (Utils.getAllPrescricoesFromUser(userID) != null) {
            menuCalendario.gerarCalendario(Utils.getAllPrescricoesFromUser(userID));
            menuCalendario.exibirCalendario();
            System.out.println("Pressione qualquer tecla para voltar ao menu principal.");
            Scanner scanner = new Scanner(System.in);
            scanner.nextLine();
            mostrarMenu();
        } else {
            System.out.println("--------------------------");
            System.out.println("Não há nada a apresentar.");
            System.out.println("--------------------------");

            mostrarMenu();
        }
    }

    // Método para acessar o glossário
    private void acessarGlossario() throws SQLException, IOException, ClassNotFoundException, NoSuchAlgorithmException {
        Glossario glossario = new Glossario(userID);
    }

    // Método para acessar o perfil do utilizador
    private void acessarPerfil() throws SQLException, IOException, NoSuchAlgorithmException, ClassNotFoundException {
        Menu_Utilizador menu_utilizador = new Menu_Utilizador(userID);
    }



    // Método para sair da aplicação
    private void sair() {
        System.out.println("Encerrando a aplicação. Adeus!");
        System.exit(0);
    }

    public Integer getIdUtilizador() {
        return userID;
    }

    public void setIdUtilizador(Integer idUtilizador) {
        this.userID = idUtilizador;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
