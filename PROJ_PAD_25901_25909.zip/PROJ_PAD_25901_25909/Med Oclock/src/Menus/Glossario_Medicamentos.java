package Menus;

import Functions.Utils;
import Objects.Medicamento;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.Scanner;

public class Glossario_Medicamentos {

    private final Integer userID;

    // Construtor que recebe o ID do utilizador
    public Glossario_Medicamentos(Integer userID) throws SQLException, IOException, ClassNotFoundException, NoSuchAlgorithmException {
        this.userID = userID;
        mostrarMenuMedicamentos();
    }

    // Método para exibir o menu relacionado aos medicamentos no glossário
    public void mostrarMenuMedicamentos() throws SQLException, IOException, ClassNotFoundException, NoSuchAlgorithmException {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("--------------");
            System.out.println("Escolha a sua opção:");
            System.out.println("--------------");
            System.out.println("1. Listar os medicamentos adicionados.");
            System.out.println("2. Editar os medicamentos adicionados.");
            System.out.println("3. Adicionar medicamento ao programa.");
            System.out.println("4. Remover os medicamentos adicionados.");
            System.out.println("0. Voltar");
            System.out.println("--------------");

            if (scanner.hasNextInt()) {
                int opcao = scanner.nextInt();
                scanner.nextLine();

                switch (opcao) {
                    case 1 -> listarMedicamentos(userID);
                    case 2 -> editarMedicamentos();
                    case 3 -> addMedicamentos();
                    case 4 -> deletarMedicamentos();
                    case 0 -> {
                        voltar();
                        return;
                    }
                    default -> System.out.println("Por favor, insira uma opção válida.");
                }
            } else {
                System.out.println("Por favor, insira uma opção válida.");
                scanner.nextLine();
            }
        }
    }

    // Método para listar os medicamentos associados a um utilizador
    public static void listarMedicamentos(Integer userID){
        Medicamento.printAllMedicamentoInfo(Medicamento.search(null, userID, null, null, null));
    }

    // Método para lidar com a edição de medicamentos
    public void editarMedicamentos() throws SQLException, IOException, ClassNotFoundException, NoSuchAlgorithmException {
        Scanner scanner = new Scanner(System.in);
        Medicamento[] medicamentos = Medicamento.search(null, null, null, null, null);

        if (medicamentos != null) {
            Object[][] numero_medicamento = Utils.transformToArrayWithNumbers(medicamentos);
            Medicamento.printAllMedicamentoInfo(Medicamento.search(null, userID, null, null, null));

            System.out.println("Por favor, selecione o número do medicamento que deseja editar:");
            System.out.println("Escreva 0 se quiser voltar.");

            if (scanner.hasNextInt()) {
                int ID = scanner.nextInt();
                scanner.nextLine();

                if (ID == 0) {
                    mostrarMenuMedicamentos();
                } else {
                    if (ID <= medicamentos.length) {
                        Medicamento medicamentoEscolhido = (Medicamento) numero_medicamento[ID - 1][1];
                        Medicamento.printMedicamentoInfo(medicamentoEscolhido.getId());

                        System.out.println("O que deseja alterar?");
                        System.out.println("1. Nome.");
                        System.out.println("2. Descrição.");
                        System.out.println("3. Tipo.");
                        System.out.println("0. Voltar.");

                        if (scanner.hasNextInt()) {
                            int opcao = scanner.nextInt();
                            scanner.nextLine();

                            switch (opcao) {
                                case 1 -> editMedicine(medicamentoEscolhido.getId(), 1);
                                case 2 -> editMedicine(medicamentoEscolhido.getId(), 2);
                                case 3 -> editMedicine(medicamentoEscolhido.getId(), 3);
                                case 0 -> {
                                    voltar();
                                    return;
                                }
                                default -> System.out.println("Por favor, insira uma opção válida.");
                            }
                        } else {
                            System.out.println("Por favor, insira uma opção válida.");
                            scanner.nextLine();
                        }
                    } else {
                        System.err.println("ID de Medicamento não existe na base de dados");
                        editarMedicamentos();
                    }
                }
            } else {
                System.out.println("Por favor, insira um número válido.");
                mostrarMenuMedicamentos();
            }
        } else {
            System.out.println("Não há medicamentos para editar.");
            mostrarMenuMedicamentos();
        }
    }

    // Método para editar um determinado atributo de um medicamento
    public void editMedicine(Integer id, Integer tipo) throws SQLException, IOException, ClassNotFoundException, NoSuchAlgorithmException {
        Medicamento medicamento = new Medicamento(id);
        Scanner scanner = new Scanner(System.in);
        System.out.println("Submeta a sua alteração:");
        String mudanca = scanner.nextLine();

        if (tipo == 1) {
            medicamento.setNome(mudanca);
        } else if (tipo == 2) {
            medicamento.setDescricao(mudanca);
        } else if (tipo == 3) {
            medicamento.setTipo(mudanca);
        }

        medicamento.store();
        System.out.println("Alterações guardadas...");
        mostrarMenuMedicamentos();
    }

    // Método para adicionar um novo medicamento
    public void addMedicamentos() throws SQLException, IOException, ClassNotFoundException, NoSuchAlgorithmException {
        Scanner scanner = new Scanner(System.in);
        Medicamento medicamento = new Medicamento();

        System.out.println("Escreva o nome do medicamento:");
        String nome = scanner.nextLine();
        medicamento.setNome(nome);

        System.out.println("Escreva a descrição do medicamento:");
        String descricao = scanner.nextLine();
        medicamento.setDescricao(descricao);

        System.out.println("Escreva o tipo do medicamento:");
        String tipo = scanner.nextLine();
        medicamento.setTipo(tipo);

        medicamento.setUtilizador_fk(userID);
        medicamento.store();
        System.out.println("Medicamento guardado.");
        mostrarMenuMedicamentos();
    }

    // Método para remover um medicamento
    public void deletarMedicamentos() throws SQLException, IOException, ClassNotFoundException, NoSuchAlgorithmException {
        Medicamento[] medicamentos = Medicamento.search(null, null, null, null, null);

        if (medicamentos != null) {
            Object[][] numero_medicamento = Utils.transformToArrayWithNumbers(medicamentos);
            Medicamento.printAllMedicamentoInfo(Medicamento.search(null, userID, null, null, null));

            System.out.println("Por favor, selecione o número do medicamento que deseja remover:");
            System.err.println("ATENÇÃO, AO REMOVER O MEDICAMENTO TAMBÉM SERÃO REMOVIDAS AS PRESCRIÇÕES E OS REGISTOS DE INGESTÃO ASSOCIADOS AO MEDICAMENTO");
            Scanner scanner = new Scanner(System.in);
            int id = scanner.nextInt();

            Medicamento medicamentoEscolhido = (Medicamento) numero_medicamento[id - 1][1];
            Medicamento.remover(medicamentoEscolhido.getId());
            System.err.println("MEDICAMENTO REMOVIDO.");
            mostrarMenuMedicamentos();
        } else {
            System.out.println("Não há medicamentos para remover.");
            mostrarMenuMedicamentos();
        }
    }

    // Método para voltar ao menu anterior
    public void voltar() throws SQLException, IOException, ClassNotFoundException, NoSuchAlgorithmException {
        Glossario glossario = new Glossario(userID);
    }

    public Integer getUserID() {
        return userID;
    }
}
