package Menus;

import Functions.Utils;
import Objects.Medicamento;
import Objects.Prescricao;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.Date;
import java.util.Scanner;

import static Functions.Utils.parseDate;
import static Functions.Utils.isValidDate;

public class Glossario {

    private Integer userID;

    // Construtor que recebe o ID do utilizador
    public Glossario(Integer userID) throws SQLException, IOException, ClassNotFoundException, NoSuchAlgorithmException {
        this.userID = userID;
        mostrarMenu();
    }

    // Método para exibir o menu do glossário
    public void mostrarMenu() throws SQLException, IOException, ClassNotFoundException, NoSuchAlgorithmException {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("--------------");
            System.out.println("Bem-vindo ao glossário.");
            System.out.println("--------------");
            System.out.println("1. Listar/editar/adicionar/remover os medicamentos.");
            System.out.println("2. Adicionar uma prescrição a si mesmo");
            System.out.println("0. Voltar");
            System.out.println("--------------");

            if (scanner.hasNextInt()) {
                int opcao = scanner.nextInt();

                switch (opcao) {
                    case 1 -> glossario_medicamentos();
                    case 2 -> add_prescricao();
                    case 0 -> {
                        voltar();
                        return;
                    }
                    default -> System.out.println("Por favor, insira uma opção válida.");
                }
            } else {
                System.out.println("Por favor, insira uma opção válida.");
            }
        }
    }

    // Método para lidar com as opções relacionadas aos medicamentos no glossário
    private void glossario_medicamentos() throws SQLException, IOException, ClassNotFoundException, NoSuchAlgorithmException {
        Glossario_Medicamentos glossario_medicamentos = new Glossario_Medicamentos(userID);
    }

    // Método para adicionar uma prescrição
    private void add_prescricao() throws SQLException, IOException, ClassNotFoundException, NoSuchAlgorithmException {
        Scanner scanner = new Scanner(System.in);
        Prescricao prescricao = new Prescricao();
        prescricao.setUtilizador_fk(userID);
        Medicamento[] medicamentos = Medicamento.search(null, userID, null, null, null);
        if (medicamentos != null) {


            // Lista os medicamentos disponíveis
            Glossario_Medicamentos.listarMedicamentos(userID);

            System.out.println("Escolha um medicamento pelo seu número");

            Object[][] numero_medicamento = Utils.transformToArrayWithNumbers(medicamentos);
            int medicineID = scanner.nextInt();
            if (medicineID < 1 || medicineID > numero_medicamento.length) {
                System.err.println("Número incorreto da medicina.");
                add_prescricao();
            }
            Medicamento medicamentoEscolhido = (Medicamento) numero_medicamento[medicineID - 1][1];

            if (medicineID <= medicamentos.length)
                prescricao.setMedicamento_fk(medicamentoEscolhido.getId());
            else {
                System.err.println("Número de medicamento incorreto.");
                add_prescricao();
            }

            System.out.println("Escreva a dosagem que deve tomar.");
            scanner.nextLine(); // Consome a quebra de linha deixada pelo nextInt()
            String dosagem = scanner.nextLine();
            prescricao.setDosagem(dosagem);

            System.out.println("Escolha a periodicidade do medicamento em dias.");
            Integer periodicidade = scanner.nextInt();
            prescricao.setPeriodicidade(periodicidade);

            System.out.println("Escreva uma breve descrição da prescrição.");
            scanner.nextLine(); // Consome a quebra de linha deixada pelo nextInt()
            String descricao = scanner.nextLine();
            prescricao.setDescricao(descricao);

            System.out.println("Insira a data de início (formato: dd/MM/aaaa): ");
            boolean valid = false;
            do {
                String startDateString = scanner.nextLine();
                if(isValidDate(startDateString)) {
                    Date startDate = parseDate(startDateString);
                    prescricao.setData_inicio(startDate);
                    valid = true;
                }else {
                    System.err.println("Data inválida");
                    System.out.println("Insira a data de início (formato: dd/MM/aaaa): ");
                }

            }while (!valid);


            System.out.println("Insira a data de fim (formato: dd/MM/aaaa): ");
            boolean valid1 = false;
            do {
                String endDateString = scanner.nextLine();
                if(isValidDate(endDateString)) {
                    Date endDate = parseDate(endDateString);
                    prescricao.setData_fim(endDate);
                    valid1 = true;
                }else {
                    System.err.println("Data invalida");
                    System.out.println("Insira a data de fim (formato: dd/MM/aaaa): ");
                }

            }while (!valid1);

            prescricao.store();
            System.out.println("Prescrição salva...");
            mostrarMenu();
        }else{
            System.out.println("Não há medicamentos para criar uma prescrição.");
            mostrarMenu();
        }
    }

    // Método para voltar ao menu principal
    private void voltar() throws SQLException, IOException, NoSuchAlgorithmException, ClassNotFoundException {
        Menu_Principal menuInicial = new Menu_Principal(userID);
        menuInicial.mostrarMenu();
    }
}
