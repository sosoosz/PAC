package Functions;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {
    // Formatos de data e hora constantes
    public static final String DateFormat = "yyyy-MM-dd HH:mm:ss";
    public static final String DateFormatSimplified = "yyyy-MM-dd";
    public static final String TimeFormat = "HH:mm:ss";

    // Configurações de conexão com o banco de dados
    private static final String endereco = "localhost";
    private static final int porta = 3306;
    private static final String usuario = "root";
    private static final String senha = "";
    private static final String bancoDados = "bdd_medoclock";
    private static final String charset = "utf8";

    private static Connection conexao = null;

    private static final String URL = "jdbc:mysql://localhost:3306/bdd_medoclock";
    private static final String USUARIO = "root";
    private static final String SENHA = "";

    // Obtém uma conexão com o banco de dados
    public static Connection getConnection() throws IOException, SQLException, ClassNotFoundException {
        if (conexao == null || !conexao.isValid(0)) {
            return DriverManager.getConnection(URL, USUARIO, SENHA);
        }
        return null;
    }

    // Obtém o próximo incremento para uma tabela específica
    public static int getNextIncrement(String tabela) {
        try {
            Statement declaracao = getConnection().createStatement();
            ResultSet resultado = declaracao.executeQuery(
                    "SELECT AUTO_INCREMENT AS val FROM INFORMATION_SCHEMA.TABLES " +
                            "WHERE table_name = '" + tabela + "' AND table_schema = '" + bancoDados + "'"
            );

            if (resultado.next()) {
                int valor = resultado.getInt("val");
                if (resultado.wasNull()) {
                    return 1;
                } else {
                    return valor;
                }
            } else {
                return 1;
            }
        } catch (IOException | SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return -1;
        }
    }
}
