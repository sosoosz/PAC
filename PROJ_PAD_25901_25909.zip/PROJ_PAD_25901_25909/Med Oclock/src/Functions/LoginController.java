package Functions;

import Objects.Utilizador;

import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

public class LoginController {
    private Integer userID;

    public LoginController() {
    }

    public boolean iniciar() throws NoSuchAlgorithmException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Bem-vindo! Já tem uma conta? S/N");
        String resposta = scanner.nextLine();

        if (resposta.equalsIgnoreCase("N")) {
            criarConta();
            System.out.println("Conta criada, por favor, faça o login.\n");
            return fazerLogin(); // Página de login após criar conta
        } else if (resposta.equalsIgnoreCase("S")) {
            return fazerLogin();
        } else {
            System.out.println("Entrada inválida. Por favor, insira S ou N.");
            return iniciar(); // Chamar recursivamente até receber uma entrada válida
        }
    }

    private void criarConta() throws NoSuchAlgorithmException {
        String nome;
        String nomeUtilizador;
        Utilizador utilizador = new Utilizador();
        int nomeUtilizadorEscolhido = 0;
        int sucesso = 0;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Certo, responda às seguintes perguntas:");
        System.out.println("Insira o seu nome:");
        nome = scanner.nextLine();
        if (!nome.isEmpty()) {
            utilizador.setNome_completo(nome);
        }

        do {
            System.out.println("Insira o seu nome de utilizador:");
            nomeUtilizador = scanner.nextLine();
            if (Utilizador.find(null, nomeUtilizador, null, null) > 0) {
                System.out.println("Nome de utilizador já existe. Por favor, escolha um diferente.");
            } else {
                utilizador.setNome_utilizador(nomeUtilizador);
                nomeUtilizadorEscolhido = 1;
            }

        } while (nomeUtilizadorEscolhido == 0); // Continua pedindo até um nome de utilizador único ser inserido

        do {
            System.out.println("Insira a sua palavra-passe:");
            String palavraPasse = scanner.nextLine();
            System.out.println("Reinsira a palavra-passe:");
            String rePalavraPasse = scanner.nextLine();
            if (palavraPasse.equals(rePalavraPasse)) {
                utilizador.setPassword(Utils.toHexString(Utils.getSHA(palavraPasse))); // Encriptação SHA256
                utilizador.store();
                sucesso = 1;
            } else {
                System.out.println("As palavras-passe não coincidem");
            }
        } while (sucesso == 0);
    }

    private boolean fazerLogin() throws NoSuchAlgorithmException {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Por favor, insira o seu nome de utilizador:");
            String nomeUtilizador = scanner.nextLine();

            System.out.println("E insira a sua palavra-passe:");
            String palavraPasse = scanner.nextLine();

            palavraPasse = Utils.toHexString(Utils.getSHA(palavraPasse));

            if (Utilizador.find(null, nomeUtilizador, null, palavraPasse) == 1) {
                Utilizador[] utilizador = Utilizador.search(null, nomeUtilizador, null, palavraPasse);
                setUserID(utilizador[0].getId());
                // Exibir o menu inicial após o login bem-sucedido
                exibirMenuInicial();
                System.out.println("--------------");
                System.out.println("Login bem-sucedido. Bem-vindo!");
                return true;

            } else {
                // Tentar novamente fazer login
                System.err.println("Login mal-sucedido.");
                System.out.println("Quer tentar novamente? (S/N)");
                String resposta = scanner.nextLine();
                if (resposta.equalsIgnoreCase("S")) {
                    continue;
                } else if (resposta.equalsIgnoreCase("N")) {
                    System.out.println("Saindo do login.");
                    return false; // Sair do processo de login
                } else {
                    System.out.println("Resposta inválida. Por favor, escolha S ou N");
                }
            }
        }
    }

    // Método para exibir o menu inicial
    private void exibirMenuInicial() {
        // Adicione aqui o código para exibir o menu inicial após o login
    }

    public Integer getUserID() {
        return userID;
    }

    public void setUserID(Integer userID) {
        this.userID = userID;
    }
}
