package Functions;

import Objects.Medicamento;
import Objects.Prescricao;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class Utils {

    // Método para obter o hash SHA-256 de uma string
    public static byte[] getSHA(String input) throws NoSuchAlgorithmException
    {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return md.digest(input.getBytes(StandardCharsets.UTF_8));
    }

    // Método para converter um array de bytes em uma representação hexadecimal
    public static String toHexString(byte[] hash)
    {
        BigInteger number = new BigInteger(1, hash);
        StringBuilder hexString = new StringBuilder(number.toString(16));

        // Preencher com zeros à esquerda se necessário
        while (hexString.length() < 32)
        {
            hexString.insert(0, '0');
        }

        return hexString.toString();
    }

    // Método para obter todas as prescrições associadas a um utilizador
    public static List<Prescricao> getAllPrescricoesFromUser(Integer utilizadorID) {
        Prescricao[] prescricaos = Prescricao.search(null, utilizadorID, null, null, null, null, null, null);
        if (prescricaos != null) {
            return new ArrayList<>(Arrays.asList(prescricaos));
        }
        return null;
    }

    // Método para fazer o parsing de uma string para um objeto Date
    public static Date parseDate(String dateString) {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        try {
            java.util.Date utilDate = format.parse(dateString);
            return new java.sql.Date(utilDate.getTime());
        } catch (ParseException e) {
            System.out.println("Formato de data inválido. Por favor, insira a data no formato correto (dd/MM/yyyy).");
            return null;
        }
    }

    // Método para transformar um array de objetos Medicamento em uma matriz bidimensional com números
    public static Object[][] transformToArrayWithNumbers(Medicamento[] objects) {
        Object[][] result = new Object[objects.length][2];

        for (int i = 0; i < objects.length; i++) {
            // Preencher a primeira coluna com números a começar em 1
            result[i][0] = i + 1;

            // Preencher a segunda coluna com o objeto correspondente
            result[i][1] = objects[i];
        }

        return result;
    }

    public static boolean isValidDate(String dateString) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        // Set strict date parsing to ensure all parts are valid
        sdf.setLenient(false);

        try {
            sdf.parse(dateString);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }
}
