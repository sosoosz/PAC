import Functions.LoginController;
import Menus.Menu_Principal;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws NoSuchAlgorithmException, SQLException, IOException, ClassNotFoundException {

        loggedin();
    }
    public static void loggedin() throws NoSuchAlgorithmException, SQLException, IOException, ClassNotFoundException {

        LoginController loginController = new LoginController();
        boolean loggedIn = loginController.iniciar();
        if (loggedIn) {
            Integer userID = loginController.getUserID();
            if (userID != null) {
                Menu_Principal menu_principal = new Menu_Principal(userID);
                menu_principal.mostrarMenu();
            } else {
                System.out.println("Falha ao recuperar informações do utilizador. Saindo da aplicação.");
            }
        }

    }




}